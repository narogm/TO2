package pl.edu.agh.school;

public enum MarkValue {
	A, B, C, D, E, F
}
