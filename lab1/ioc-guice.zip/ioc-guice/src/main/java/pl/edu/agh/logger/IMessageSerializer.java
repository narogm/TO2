package pl.edu.agh.logger;

public interface IMessageSerializer {

	public void serializeMessage(String message);
}
